# Crypto Paper Trader — Android sample

This is a simulation app. It does NOT connect to Maya and does NOT place real trades.

## What it demonstrates
- Manual price updates
- Rising/falling detection
- Configurable percentage triggers
- Simulated BUY/SELL
- Virtual ₱10,000 balance
- Virtual coin holdings
- P/L calculation

## Build
Open this folder in Android Studio. Let Gradle sync, then choose:
Build > Build Bundle(s) / APK(s) > Build APK(s).

The APK will normally be under:
app/build/outputs/apk/debug/app-debug.apk

## Next phase
For a safer real-world prototype, add screenshot/OCR price detection and a paper-trading log first. Do not connect it to a real-money account until you have verified platform permissions and the strategy.
