package com.example.mayacryptopapertrader;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import android.graphics.Color;
import java.util.Locale;

public class MainActivity extends Activity {
    EditText edtPrice, edtBuyPct, edtSellPct;
    TextView txtPrice, txtTrend, txtSignal, txtCash, txtCoins, txtPnl;
    double lastPrice = 0, cash = 10000, coins = 0, entryValue = 0;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        edtPrice=findViewById(R.id.edtPrice); edtBuyPct=findViewById(R.id.edtBuyPct); edtSellPct=findViewById(R.id.edtSellPct);
        txtPrice=findViewById(R.id.txtPrice); txtTrend=findViewById(R.id.txtTrend); txtSignal=findViewById(R.id.txtSignal);
        txtCash=findViewById(R.id.txtCash); txtCoins=findViewById(R.id.txtCoins); txtPnl=findViewById(R.id.txtPnl);

        findViewById(R.id.btnUpdate).setOnClickListener(v -> updatePrice());
        findViewById(R.id.btnReset).setOnClickListener(v -> reset());
        render();
    }

    void updatePrice() {
        try {
            double p=Double.parseDouble(edtPrice.getText().toString());
            if (p<=0) return;
            double buyPct=Double.parseDouble(edtBuyPct.getText().toString())/100.0;
            double sellPct=Double.parseDouble(edtSellPct.getText().toString())/100.0;
            String signal="WAIT";

            if (lastPrice>0) {
                if (p>lastPrice) txtTrend.setText("Trend: RISING");
                else if (p<lastPrice) txtTrend.setText("Trend: FALLING");
                else txtTrend.setText("Trend: FLAT");

                if (p <= lastPrice*(1.0-buyPct) && cash>0) {
                    double spend=cash;
                    coins += spend/p;
                    cash=0;
                    entryValue=p;
                    signal="SIMULATED BUY";
                } else if (p >= lastPrice*(1.0+sellPct) && coins>0) {
                    cash += coins*p;
                    coins=0;
                    entryValue=0;
                    signal="SIMULATED SELL";
                }
            }
            lastPrice=p;
            txtSignal.setText("Signal: "+signal);
            render();
        } catch(Exception ignored) {}
    }

    void render() {
        txtPrice.setText(String.format(Locale.US,"Price: ₱%,.2f",lastPrice));
        txtCash.setText(String.format(Locale.US,"Cash: ₱%,.2f",cash));
        txtCoins.setText(String.format(Locale.US,"Coins: %.6f",coins));
        double equity=cash+coins*lastPrice;
        double pnl=equity-10000;
        txtPnl.setText(String.format(Locale.US,"P/L: ₱%,.2f",pnl));
    }

    void reset() {
        lastPrice=0; cash=10000; coins=0; entryValue=0;
        txtTrend.setText("Trend: —"); txtSignal.setText("Signal: WAIT"); render();
    }
}
